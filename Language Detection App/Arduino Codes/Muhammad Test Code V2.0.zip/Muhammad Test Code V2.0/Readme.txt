Changed the Voice Pattern and also the array sequence only,
D2, D3 ---> Software serial pins
D1,D2,D8 are the RGB leds conection.

Check the power and also the serial monitor while running the program to 
so that we could find out some error.










DevoMech Solutions
